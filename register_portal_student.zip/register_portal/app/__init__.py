from flask import Flask

from config import Config
from app.extensions import db


def create_app(config_class=Config):
    app = Flask(__name__)
    app.config.from_object(config_class)
    db.init_app(app)

    # import models để SQLAlchemy biết các bảng
    from app import models  # noqa: F401

    # BillingSystem: đổi sang bản thật ở đây khi có
    from app.integrations.mock_billing_system import MockBillingSystem
    app.extensions["billing_system"] = MockBillingSystem()

    from app.routes.auth_routes import auth_bp
    from app.routes.student_routes import student_bp
    app.register_blueprint(auth_bp)
    app.register_blueprint(student_bp)

    return app
