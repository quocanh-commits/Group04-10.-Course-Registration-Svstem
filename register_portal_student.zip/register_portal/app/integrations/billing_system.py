from abc import ABC, abstractmethod
from dataclasses import dataclass


@dataclass
class BillingResult:
    success: bool
    transaction_ref: str | None = None
    message: str = ""


class BillingSystem(ABC):
    """Interface hệ thống thanh toán bên ngoài."""

    @abstractmethod
    def charge(self, student_id: str, amount: int, payment_id: int) -> BillingResult:
        ...
