import uuid
from app.integrations.billing_system import BillingSystem, BillingResult


class MockBillingSystem(BillingSystem):
    """Bản giả lập: luôn thành công (trừ số tiền <= 0)."""

    def charge(self, student_id: str, amount: int, payment_id: int) -> BillingResult:
        if amount <= 0:
            return BillingResult(False, None, "Số tiền không hợp lệ")
        return BillingResult(True, f"MOCK-{uuid.uuid4().hex[:10].upper()}", "OK")
