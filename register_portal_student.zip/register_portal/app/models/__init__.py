from app.models.user import User, Student
from app.models.course import Course
from app.models.registration_term import RegistrationTerm
from app.models.class_section import ClassSection
from app.models.enrollment import Enrollment
from app.models.wishlist_record import WishlistRecord
from app.models.payment import Payment

__all__ = ["User", "Student", "Course", "RegistrationTerm", "ClassSection",
           "Enrollment", "WishlistRecord", "Payment"]
