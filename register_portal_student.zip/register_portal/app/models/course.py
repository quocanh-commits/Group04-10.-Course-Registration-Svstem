from app.extensions import db


class Course(db.Model):
    __tablename__ = "courses"

    course_id = db.Column(db.String(20), primary_key=True)
    name = db.Column(db.String(150), nullable=False)
    credits = db.Column(db.Integer, nullable=False)
    department = db.Column(db.String(100))
