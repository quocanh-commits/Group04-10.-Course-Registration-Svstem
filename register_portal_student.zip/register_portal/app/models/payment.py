from datetime import datetime
from app.extensions import db

PENDING = "PENDING"
SUCCESS = "SUCCESS"
FAILED = "FAILED"


class Payment(db.Model):
    __tablename__ = "payments"

    payment_id = db.Column(db.Integer, primary_key=True)
    student_id = db.Column(db.String(20), db.ForeignKey("users.user_id"), nullable=False)
    term_id = db.Column(db.Integer, db.ForeignKey("registration_terms.term_id"), nullable=False)
    amount = db.Column(db.Integer, nullable=False)
    status = db.Column(db.String(10), nullable=False, default=PENDING)
    transaction_ref = db.Column(db.String(60))
    created_at = db.Column(db.DateTime, default=datetime.now)
