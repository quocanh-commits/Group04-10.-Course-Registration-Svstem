from datetime import datetime
from app.extensions import db


class RegistrationTerm(db.Model):
    __tablename__ = "registration_terms"

    term_id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(50), nullable=False)       # vd: HK1 2025-2026
    start_at = db.Column(db.DateTime, nullable=False)
    end_at = db.Column(db.DateTime, nullable=False)
    is_active = db.Column(db.Boolean, default=True, nullable=False)

    def is_open(self) -> bool:
        return self.is_active and self.start_at <= datetime.now() <= self.end_at
