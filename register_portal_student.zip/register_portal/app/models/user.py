import bcrypt
from app.extensions import db


class User(db.Model):
    """Lớp trừu tượng User (single-table inheritance theo cột `role`)."""
    __tablename__ = "users"

    user_id = db.Column(db.String(20), primary_key=True)
    full_name = db.Column(db.String(100), nullable=False)
    password_hash = db.Column(db.String(128), nullable=False)
    date_of_birth = db.Column(db.Date)
    email = db.Column(db.String(120), unique=True)
    role = db.Column(db.String(20), nullable=False)

    __mapper_args__ = {"polymorphic_on": role, "polymorphic_identity": "user"}

    def set_password(self, raw: str) -> None:
        self.password_hash = bcrypt.hashpw(raw.encode(), bcrypt.gensalt()).decode()

    def check_password(self, raw: str) -> bool:
        return bcrypt.checkpw(raw.encode(), self.password_hash.encode())


class Student(User):
    major = db.Column(db.String(100))
    enrollment_year = db.Column(db.Integer)

    __mapper_args__ = {"polymorphic_identity": "student"}
