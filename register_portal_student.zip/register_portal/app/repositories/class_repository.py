from app.extensions import db
from app.models import ClassSection, Course


def get(class_id: str):
    return db.session.get(ClassSection, class_id)


def search(term_id: int, keyword: str = ""):
    q = ClassSection.query.join(Course).filter(ClassSection.term_id == term_id)
    if keyword:
        like = f"%{keyword}%"
        q = q.filter(db.or_(Course.course_id.ilike(like), Course.name.ilike(like),
                            ClassSection.class_id.ilike(like)))
    return q.order_by(ClassSection.class_id).all()
