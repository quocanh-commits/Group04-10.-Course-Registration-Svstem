from app.extensions import db
from app.models import Course


def get(course_id: str):
    return db.session.get(Course, course_id)


def search(keyword: str = ""):
    q = Course.query
    if keyword:
        like = f"%{keyword}%"
        q = q.filter(db.or_(Course.course_id.ilike(like), Course.name.ilike(like)))
    return q.order_by(Course.course_id).all()
