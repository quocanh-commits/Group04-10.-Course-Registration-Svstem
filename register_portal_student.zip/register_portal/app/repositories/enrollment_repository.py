from app.extensions import db
from app.models import Enrollment, ClassSection
from app.models.enrollment import REGISTERED


def find(student_id: str, class_id: str):
    return Enrollment.query.filter_by(student_id=student_id, class_id=class_id).first()


def active_in_term(student_id: str, term_id: int):
    return (Enrollment.query.join(ClassSection)
            .filter(Enrollment.student_id == student_id,
                    Enrollment.status == REGISTERED,
                    ClassSection.term_id == term_id)
            .order_by(ClassSection.day_of_week, ClassSection.start_period).all())


def count_active_in_class(class_id: str) -> int:
    return Enrollment.query.filter_by(class_id=class_id, status=REGISTERED).count()


def all_active(student_id: str):
    return Enrollment.query.filter_by(student_id=student_id, status=REGISTERED).all()


def save(enrollment: Enrollment) -> Enrollment:
    db.session.add(enrollment)
    db.session.commit()
    return enrollment
