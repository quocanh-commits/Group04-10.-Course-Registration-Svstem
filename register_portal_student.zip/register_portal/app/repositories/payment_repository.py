from sqlalchemy import func
from app.extensions import db
from app.models import Payment
from app.models.payment import SUCCESS


def save(payment: Payment) -> Payment:
    db.session.add(payment)
    db.session.commit()
    return payment


def list_by_student(student_id: str):
    return (Payment.query.filter_by(student_id=student_id)
            .order_by(Payment.created_at.desc()).all())


def total_paid(student_id: str, term_id: int) -> int:
    total = (db.session.query(func.coalesce(func.sum(Payment.amount), 0))
             .filter_by(student_id=student_id, term_id=term_id, status=SUCCESS).scalar())
    return int(total)
