from app.extensions import db
from app.models import RegistrationTerm


def get(term_id: int):
    return db.session.get(RegistrationTerm, term_id)


def get_open_term():
    for t in RegistrationTerm.query.filter_by(is_active=True).order_by(RegistrationTerm.start_at.desc()):
        if t.is_open():
            return t
    return None


def get_latest_term():
    return RegistrationTerm.query.order_by(RegistrationTerm.start_at.desc()).first()
