from app.extensions import db
from app.models import User


def get(user_id: str):
    return db.session.get(User, user_id)
