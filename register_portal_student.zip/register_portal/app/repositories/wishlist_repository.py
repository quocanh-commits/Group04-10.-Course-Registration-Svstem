from app.extensions import db
from app.models import WishlistRecord


def get(record_id: int):
    return db.session.get(WishlistRecord, record_id)


def find(student_id: str, course_id: str):
    return WishlistRecord.query.filter_by(student_id=student_id, course_id=course_id).first()


def list_by_student(student_id: str):
    return (WishlistRecord.query.filter_by(student_id=student_id)
            .order_by(WishlistRecord.added_date.desc()).all())


def save(record: WishlistRecord) -> WishlistRecord:
    db.session.add(record)
    db.session.commit()
    return record


def delete(record: WishlistRecord) -> None:
    db.session.delete(record)
    db.session.commit()
