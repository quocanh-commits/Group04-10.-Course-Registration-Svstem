from flask import Blueprint, flash, redirect, render_template, request, session, url_for

from app.services import auth_service

auth_bp = Blueprint("auth", __name__)


@auth_bp.route("/")
def index():
    if session.get("role") == "student":
        return redirect(url_for("student.course_search"))
    return redirect(url_for("auth.sign_in"))


@auth_bp.route("/sign-in", methods=["GET", "POST"])
def sign_in():
    if request.method == "POST":
        user = auth_service.authenticate(request.form["user_id"], request.form["password"])
        if not user:
            flash("Sai mã đăng nhập hoặc mật khẩu.", "error")
        else:
            session.clear()
            session["user_id"], session["role"], session["full_name"] = user.user_id, user.role, user.full_name
            if user.role == "student":
                return redirect(url_for("student.course_search"))
            flash("Giao diện cho vai trò này chưa được làm.", "error")
    return render_template("sign_in.html")


@auth_bp.route("/sign-out")
def sign_out():
    session.clear()
    return redirect(url_for("auth.sign_in"))
