from flask import Blueprint, flash, redirect, render_template, request, session, url_for

from app.routes.decorators import role_required
from app.services import (search_service, registration_service, wishlist_service,
                          class_service, payment_service)

student_bp = Blueprint("student", __name__, url_prefix="/student")


def _uid() -> str:
    return session["user_id"]


def _flash(result):
    flash(result.message, "success" if result.ok else "error")


# ---- Tra cứu học phần (3.0) ----
@student_bp.route("/courses")
@role_required("student")
def course_search():
    keyword = request.args.get("q", "")
    return render_template("student/course_search.html",
                           courses=search_service.search_courses(keyword),
                           wished=wishlist_service.wished_course_ids(_uid()),
                           keyword=keyword)


# ---- Đăng ký lớp (4.0) ----
@student_bp.route("/registration")
@role_required("student")
def course_reg():
    keyword = request.args.get("q", "")
    term, classes = search_service.search_classes_in_open_term(keyword)
    registered = registration_service.get_registered(_uid(), term.term_id) if term else []
    return render_template("student/course_reg.html", term=term, classes=classes,
                           registered=registered,
                           registered_ids={e.class_id for e in registered},
                           total_credits=sum(e.class_section.course.credits for e in registered),
                           keyword=keyword)


@student_bp.route("/registration/register", methods=["POST"])
@role_required("student")
def register_class():
    _flash(registration_service.register_class(_uid(), request.form["class_id"]))
    return redirect(url_for("student.course_reg"))


@student_bp.route("/registration/cancel", methods=["POST"])
@role_required("student")
def cancel_class():
    _flash(registration_service.cancel_class(_uid(), request.form["class_id"]))
    return redirect(url_for("student.course_reg"))


# ---- Wishlist (4.0) ----
@student_bp.route("/wishlist")
@role_required("student")
def wishlist():
    return render_template("student/wishlist.html", records=wishlist_service.list_wishlist(_uid()))


@student_bp.route("/wishlist/add", methods=["POST"])
@role_required("student")
def wishlist_add():
    _flash(wishlist_service.add_to_wishlist(_uid(), request.form["course_id"]))
    return redirect(request.referrer or url_for("student.wishlist"))


@student_bp.route("/wishlist/<int:record_id>/request", methods=["POST"])
@role_required("student")
def wishlist_request(record_id):
    _flash(wishlist_service.request_approval(_uid(), record_id))
    return redirect(url_for("student.wishlist"))


@student_bp.route("/wishlist/<int:record_id>/remove", methods=["POST"])
@role_required("student")
def wishlist_remove(record_id):
    _flash(wishlist_service.remove(_uid(), record_id))
    return redirect(url_for("student.wishlist"))


# ---- Thời khóa biểu / Kết quả (5.0) ----
@student_bp.route("/timetable")
@role_required("student")
def timetable():
    term, enrollments = class_service.get_timetable(_uid())
    return render_template("student/timetable.html", term=term, enrollments=enrollments)


@student_bp.route("/results")
@role_required("student")
def results():
    rows, gpa = class_service.get_results(_uid())
    return render_template("student/results.html", rows=rows, gpa=gpa)


# ---- Học phí (6.0) ----
@student_bp.route("/tuition")
@role_required("student")
def tuition():
    return render_template("student/tuition.html", s=payment_service.tuition_summary(_uid()))


@student_bp.route("/tuition/pay", methods=["POST"])
@role_required("student")
def pay():
    _flash(payment_service.make_payment(_uid()))
    return redirect(url_for("student.tuition"))
