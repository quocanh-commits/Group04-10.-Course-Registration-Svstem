from app.repositories import user_repository


def authenticate(user_id: str, password: str):
    """Trả về User nếu đúng, None nếu sai."""
    user = user_repository.get(user_id.strip())
    if user and user.check_password(password):
        return user
    return None
