"""5.0 - Thông tin lớp: thời khóa biểu, kết quả học tập."""
from app.repositories import enrollment_repository, term_repository

MIDTERM_WEIGHT = 0.4   # giả định, chỉnh theo quy chế của trường
FINAL_WEIGHT = 0.6


def _letter(score10: float):
    if score10 >= 8.5: return "A", 4.0
    if score10 >= 7.0: return "B", 3.0
    if score10 >= 5.5: return "C", 2.0
    if score10 >= 4.0: return "D", 1.0
    return "F", 0.0


def get_timetable(student_id: str):
    term = term_repository.get_open_term() or term_repository.get_latest_term()
    if not term:
        return None, []
    return term, enrollment_repository.active_in_term(student_id, term.term_id)


def get_results(student_id: str):
    """Trả về (danh sách dòng điểm, GPA hệ 4)."""
    rows, points, credits = [], 0.0, 0
    for e in enrollment_repository.all_active(student_id):
        row = {"enrollment": e, "total": None, "letter": None}
        if e.midterm is not None and e.final is not None:
            total = round(e.midterm * MIDTERM_WEIGHT + e.final * FINAL_WEIGHT, 2)
            letter, gp = _letter(total)
            row.update(total=total, letter=letter)
            c = e.class_section.course.credits
            points += gp * c
            credits += c
        rows.append(row)
    gpa = round(points / credits, 2) if credits else None
    return rows, gpa
