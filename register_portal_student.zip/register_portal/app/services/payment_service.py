"""6.0 - Học phí và thanh toán."""
from flask import current_app

from app.models import Payment
from app.models.payment import SUCCESS, FAILED
from app.repositories import enrollment_repository, payment_repository, term_repository
from app.services.result import ServiceResult


def tuition_summary(student_id: str):
    term = term_repository.get_open_term() or term_repository.get_latest_term()
    if not term:
        return None
    enrollments = enrollment_repository.active_in_term(student_id, term.term_id)
    credits = sum(e.class_section.course.credits for e in enrollments)
    total = credits * current_app.config["TUITION_PER_CREDIT"]
    paid = payment_repository.total_paid(student_id, term.term_id)
    return {"term": term, "enrollments": enrollments, "credits": credits,
            "total": total, "paid": paid, "remaining": max(total - paid, 0),
            "payments": payment_repository.list_by_student(student_id)}


def make_payment(student_id: str) -> ServiceResult:
    summary = tuition_summary(student_id)
    if not summary or summary["remaining"] <= 0:
        return ServiceResult(False, "Không có khoản học phí nào cần thanh toán.")

    payment = payment_repository.save(Payment(
        student_id=student_id, term_id=summary["term"].term_id, amount=summary["remaining"]))

    billing = current_app.extensions["billing_system"]
    result = billing.charge(student_id, payment.amount, payment.payment_id)

    payment.status = SUCCESS if result.success else FAILED
    payment.transaction_ref = result.transaction_ref
    payment_repository.save(payment)

    if result.success:
        return ServiceResult(True, f"Thanh toán {payment.amount:,} đ thành công.", payment)
    return ServiceResult(False, f"Thanh toán thất bại: {result.message}", payment)
