"""4.0 - Đăng ký / hủy lớp học phần."""
from flask import current_app

from app.models import Enrollment
from app.models.enrollment import REGISTERED, CANCELLED
from app.repositories import class_repository, enrollment_repository
from app.services.result import ServiceResult


def register_class(student_id: str, class_id: str) -> ServiceResult:
    cls = class_repository.get(class_id)
    if not cls:
        return ServiceResult(False, "Lớp học phần không tồn tại.")
    if not cls.term.is_open():
        return ServiceResult(False, "Đợt đăng ký chưa mở hoặc đã đóng.")

    existing = enrollment_repository.find(student_id, class_id)
    if existing and existing.status == REGISTERED:
        return ServiceResult(False, "Bạn đã đăng ký lớp này rồi.")

    current = enrollment_repository.active_in_term(student_id, cls.term_id)

    if any(e.class_section.course_id == cls.course_id for e in current):
        return ServiceResult(False, "Bạn đã đăng ký một lớp khác của học phần này.")

    total = sum(e.class_section.course.credits for e in current) + cls.course.credits
    if total > current_app.config["MAX_CREDITS"]:
        return ServiceResult(False, f"Vượt quá {current_app.config['MAX_CREDITS']} tín chỉ cho phép.")

    for e in current:
        if cls.conflicts_with(e.class_section):
            return ServiceResult(False, f"Trùng lịch với lớp {e.class_id}.")

    if enrollment_repository.count_active_in_class(class_id) >= cls.capacity:
        return ServiceResult(False, "Lớp đã đủ sĩ số.")

    if existing:                      # từng hủy -> kích hoạt lại
        existing.status = REGISTERED
        enrollment = existing
    else:
        enrollment = Enrollment(student_id=student_id, class_id=class_id)
    enrollment_repository.save(enrollment)
    return ServiceResult(True, f"Đăng ký thành công lớp {class_id}.", enrollment)


def cancel_class(student_id: str, class_id: str) -> ServiceResult:
    enrollment = enrollment_repository.find(student_id, class_id)
    if not enrollment or enrollment.status != REGISTERED:
        return ServiceResult(False, "Bạn chưa đăng ký lớp này.")
    if not enrollment.class_section.term.is_open():
        return ServiceResult(False, "Đã hết thời gian hủy đăng ký.")
    if enrollment.midterm is not None or enrollment.final is not None:
        return ServiceResult(False, "Lớp đã có điểm, không thể hủy.")
    enrollment.status = CANCELLED
    enrollment_repository.save(enrollment)
    return ServiceResult(True, f"Đã hủy lớp {class_id}.")


def get_registered(student_id: str, term_id: int):
    return enrollment_repository.active_in_term(student_id, term_id)
