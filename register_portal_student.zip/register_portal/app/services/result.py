from dataclasses import dataclass
from typing import Any


@dataclass
class ServiceResult:
    ok: bool
    message: str
    data: Any = None
