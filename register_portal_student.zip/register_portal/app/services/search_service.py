"""3.0 - Tra cứu học phần / lớp học phần."""
from app.repositories import course_repository, class_repository, term_repository


def search_courses(keyword: str = ""):
    return course_repository.search(keyword.strip())


def search_classes_in_open_term(keyword: str = ""):
    term = term_repository.get_open_term()
    if not term:
        return None, []
    return term, class_repository.search(term.term_id, keyword.strip())
