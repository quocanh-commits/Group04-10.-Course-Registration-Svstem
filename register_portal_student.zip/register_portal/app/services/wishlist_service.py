"""4.0 - Wishlist: sinh viên thêm môn muốn học, gửi yêu cầu duyệt (admin duyệt ở bước sau)."""
from app.models import WishlistRecord
from app.models.wishlist_record import DRAFT, PENDING, APPROVED, REJECTED
from app.repositories import course_repository, wishlist_repository
from app.services.result import ServiceResult


def list_wishlist(student_id: str):
    return wishlist_repository.list_by_student(student_id)


def wished_course_ids(student_id: str) -> set:
    return {r.course_id for r in wishlist_repository.list_by_student(student_id)}


def add_to_wishlist(student_id: str, course_id: str) -> ServiceResult:
    if not course_repository.get(course_id):
        return ServiceResult(False, "Học phần không tồn tại.")
    if wishlist_repository.find(student_id, course_id):
        return ServiceResult(False, "Học phần đã có trong wishlist.")
    wishlist_repository.save(WishlistRecord(student_id=student_id, course_id=course_id,
                                            approval_status=DRAFT))
    return ServiceResult(True, "Đã thêm vào wishlist.")


def request_approval(student_id: str, record_id: int) -> ServiceResult:
    record = wishlist_repository.get(record_id)
    if not record or record.student_id != student_id:
        return ServiceResult(False, "Không tìm thấy mục wishlist.")
    if record.approval_status not in (DRAFT, REJECTED):
        return ServiceResult(False, "Mục này đã gửi duyệt hoặc đã được duyệt.")
    record.approval_status = PENDING
    wishlist_repository.save(record)
    return ServiceResult(True, "Đã gửi yêu cầu duyệt.")


def remove(student_id: str, record_id: int) -> ServiceResult:
    record = wishlist_repository.get(record_id)
    if not record or record.student_id != student_id:
        return ServiceResult(False, "Không tìm thấy mục wishlist.")
    if record.approval_status == APPROVED:
        return ServiceResult(False, "Mục đã được duyệt, không thể xóa.")
    wishlist_repository.delete(record)
    return ServiceResult(True, "Đã xóa khỏi wishlist.")
