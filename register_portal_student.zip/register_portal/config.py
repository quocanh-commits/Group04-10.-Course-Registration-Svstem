import os


class Config:
    SECRET_KEY = os.environ.get("SECRET_KEY", "dev-secret-change-me")
    SQLALCHEMY_DATABASE_URI = os.environ.get("DATABASE_URL", "sqlite:///register_portal.db")
    SQLALCHEMY_TRACK_MODIFICATIONS = False
    MAX_CREDITS = 24
    TUITION_PER_CREDIT = 500_000
