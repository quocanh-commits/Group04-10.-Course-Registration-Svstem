"""Tạo dữ liệu mẫu để chạy thử phần Student:  python -m scripts.seed_demo"""
import sys, pathlib
sys.path.insert(0, str(pathlib.Path(__file__).resolve().parent.parent))

from datetime import datetime, timedelta, date
from app import create_app
from app.extensions import db
from app.models import Student, Course, RegistrationTerm, ClassSection

app = create_app()
with app.app_context():
    db.drop_all()
    db.create_all()

    sv = Student(user_id="SV001", full_name="Nguyễn Văn A", email="a@example.com",
                 date_of_birth=date(2004, 1, 1), major="CNTT", enrollment_year=2023)
    sv.set_password("123456")
    db.session.add(sv)

    term = RegistrationTerm(name="HK1 2026-2027", start_at=datetime.now() - timedelta(days=1),
                            end_at=datetime.now() + timedelta(days=30))
    db.session.add(term)
    db.session.flush()

    courses = [("INT101", "Nhập môn lập trình", 3), ("INT102", "Cơ sở dữ liệu", 3),
               ("INT103", "Mạng máy tính", 3), ("MAT101", "Giải tích 1", 4)]
    for cid, name, cr in courses:
        db.session.add(Course(course_id=cid, name=name, credits=cr, department="CNTT"))

    # INT102.01 và INT103.01 trùng lịch để thử kiểm tra xung đột
    classes = [("INT101.01", "INT101", 2, 1, 3, "A101"), ("INT102.01", "INT102", 3, 1, 3, "A102"),
               ("INT103.01", "INT103", 3, 2, 4, "B201"), ("MAT101.01", "MAT101", 4, 7, 10, "C301")]
    for clid, cid, day, s, e, room in classes:
        db.session.add(ClassSection(class_id=clid, course_id=cid, term_id=term.term_id,
                                    day_of_week=day, start_period=s, end_period=e,
                                    room=room, capacity=40))
    db.session.commit()
    print("Seed xong. Đăng nhập: SV001 / 123456")
